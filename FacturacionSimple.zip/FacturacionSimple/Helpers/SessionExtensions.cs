using System;
using FacturacionSimple.Models;
using Newtonsoft.Json;

namespace FacturacionSimple.Helpers;

public static class SessionObjects
{

    public static IndexViewModel VM {get;set;}
    

}
