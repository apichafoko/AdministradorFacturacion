using System;

namespace FacturacionSimple.Helpers;

public class ItemCirujanoDTO
{
    public string Nombre {get;set;}

    public int Cantidad {get;set;}

    public double Monto {get;set;}

    public double Porcentaje {get;set;}

    

}
