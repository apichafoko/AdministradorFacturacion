﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

public class ProgressHub : Hub
{
    // Puedes implementar métodos adicionales si es necesario
}
