﻿using System;
namespace FacturacionSimple.Models
{
    public class Entidad
    {
        public int Id { get; set; }
        public int Codigo { get; set; }
        public string Nombre { get; set; }
    }
}

